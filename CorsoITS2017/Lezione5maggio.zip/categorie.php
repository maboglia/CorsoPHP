<?php

include './includes/header.php';

?>

<div class="container">
    
<?php
//
include './includes/content.php';



//include './includes/sidebar.php';

?>

</div>

<?php


include './includes/footer.php';



